# Life Qilla Plus Marque — Management App

A simple installable Progressive Web App (PWA) for one marque. No photos or decorative image content in the interface.

## Included
- Dashboard with bookings, upcoming events, received amount and outstanding balance
- Create/edit/delete bookings and prevent two active bookings on the same date
- Booking calendar
- Customer list
- Payment entries and payment history
- Monthly and overall reports
- CSV export and JSON backup/restore
- Installable on Android from a GitHub Pages URL; offline app shell after first visit

## Publish using GitHub Pages
1. Open the GitHub repository you already created.
2. Upload **all files and folders inside this ZIP** (not the ZIP file itself) to the repository's root.
3. Commit the files to the `main` branch.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main**, folder **/(root)**, then click **Save**.
7. Wait for GitHub Pages to publish. The site URL appears on the Pages screen, usually `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Install on Android
1. Open the published GitHub Pages URL in Chrome on your phone.
2. Tap the browser menu (⋮) → **Install app** or **Add to Home screen**.
3. Confirm. The app icon will appear on your home screen and open in app-style full screen.

## Important data note
This starter version saves data in the browser's local storage on this phone only. It does **not** sync between devices, and it has no owner login or cloud database yet. Use Settings → Download Backup regularly. Do not publish customer data in GitHub. For multi-device access, secure login and automatic cloud backup, a private database/backend must be added in a next phase.
